<?php

$HOST = "localhost";
$DB_NAME = "PHP2022";
$USER = "jacopot";
$PASSWORD = "password";

try {
    $DB = new PDO("mysql:host=$HOST;dbname=$DB_NAME", $USER, $PASSWORD);
} catch (PDOException $e) {
    echo "Impossibile connettersi: " . $e->getMessage();
}
