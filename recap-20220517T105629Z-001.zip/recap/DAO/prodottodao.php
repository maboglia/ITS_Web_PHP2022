<?php

require_once "../DAO/connessione.php";
require_once "../model/prodotto.php";

class ProdottoDAO
{
    public function addProdotto($p)
    {
        //$p = new Prodotto(1, "granapadano doc", "formaggio", 5);
        global $DB;

        try {
            $DB->query("INSERT INTO prodotti (nome, descrizione, quantita) VALUES ('$p->nome', '$p->descrizione', $p->quantita)");
        } catch (PDOException $exception) {
            echo $exception->getMessage();
        }
    }

    public function getProdotti()
    {
        global $DB;

        try {
            $result = $DB->query("SELECT * FROM prodotti");

            $result->setFetchMode(PDO::FETCH_CLASS, "Prodotto");
            //$result->setFetchMode(PDO::FETCH_OBJ);

            $prodotti = [];
            while ($prodotto = $result->fetch()) {
                $prodotti[] = $prodotto;
            }

            return $prodotti;
        } catch (PDOException $exception) {
            echo $exception->getMessage();
        }
    }
}
