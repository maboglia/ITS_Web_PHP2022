<?php

require_once "../DAO/prodottodao.php";

class ProdottoCTRL
{
    public function index()
    {
        $prodotti = new ProdottoDAO();
        //print_r($prodotti->getProdotti());
        header("ContentType:application/json");
        header("Access-Control-Allow-Origin: *");
        echo json_encode($prodotti->getProdotti());
    }
}

$controller = new ProdottoCTRL();
$controller->index();
