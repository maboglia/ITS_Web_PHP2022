<?php

class Prodotto
{
    public $id;
    public $nome;
    public $descrizione;
    public $quantita;

    public function __construct()
    {
    }

    public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name = $value;
    }
}
