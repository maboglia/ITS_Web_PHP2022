<?php

/* ----- ECHO VARIABLE ----- */

$nome = "Jacopo";

$_SESSION["biscotto_server"] = $nome;

echo $nome . " ";

/* ----- CHECK IF GET VARIABLE IS SET AND ECHO ----- */

// METHOD 1
/* if(isset($_GET["cognome"])) {
    echo $_GET["cognome"];
}*/

// METHOD 2
//echo (isset($_GET["cognome"])) ? $_GET["cognome"] : "";

// METHOD 3
echo $coalesce = $_GET["cognome"] ?? "";

/* ----- CONSTANT VARIABLES ----- */

define("IVA", 0.22);

?>

<!-- FOREACH IN HTML -->
<!-- $_REQUEST == $_GET + $_POST -->

<?php foreach ($_SERVER as $key => $value) : ?>

    <p><?= $key . ": " . $value ?></p> <!-- inline echo -->

<?php endforeach ?>